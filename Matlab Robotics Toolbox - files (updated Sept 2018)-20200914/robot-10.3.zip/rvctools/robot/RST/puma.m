       clear
       load exampleRobots